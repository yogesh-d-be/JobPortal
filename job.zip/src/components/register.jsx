import React from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faEnvelope, faLock, faMobile, faUser } from '@fortawesome/free-solid-svg-icons';
import '../components/register.css'
function Register() {
    return (
        <>
            <div className="relative w-[100%] min-h-[100vh] bg-white overflow-hidden before:bg-gradient-to-t from-blue-500 via-blue-500 before:absolute before:top-[-10%] before:transform before:-translate-y-1/2 before:w-[2000px] before:h-[2000px] before:rounded-[50%] before:right-1/2">
                <div className="absolute w-[100%] h-[100%] top-0 left-0">
                    <div className="absolute top-[30%] left-[95%] w-1/2 -translate-x-1/2 -translate-y-1/2 grid grid-cols-1 grid-rows-1">
                        <form className="absolute flex flex-col justify-center items-center col-span-1 row-span-1 z-10 ">
                            <div>
                            <h2 className="text-2xl text-gray-700 mb-3 font-bold">Sign In</h2>
                            <div className="max-w-[300px] w-full h-12 bg-gray-200 my-4 rounded-xl flex items-center">
                                <span className="w-[30px] justify-center ml-4"><FontAwesomeIcon icon={faEnvelope} /></span>
                                <input type="email" placeholder="Email ID" className="w-[250px] bg-transparent outline-none" />
                            </div>
                            <div className="max-w-[300px] w-full h-12 bg-gray-200 my-4 rounded-xl flex items-center">
                                <span className="w-[30px] justify-center ml-4"><FontAwesomeIcon icon={faLock} /></span>
                                <input type="text" placeholder="Password" className="w-[250px] bg-transparent outline-none" />
                            </div>
                            <button type="submit" className="bg-blue-500 text-white font-semibold py-2 px-8 rounded-3xl transition-all ease-in-out duration-300 hover:ring hover:ring-blue-500 hover:bg-white hover:text-blue-500">Login</button>
                            </div>
                        </form>

                        <form className="absolute flex flex-col justify-center items-center  col-span-1 row-span-1 z-1 opacity-0">
                            <div>
                            <h2 className="text-2xl text-gray-700 mb-3 font-bold">Sign Up</h2>
                            <div className="max-w-[300px] w-full h-12 bg-gray-200 my-4 rounded-xl flex items-center">
                                <span className="w-[30px] justify-center ml-4"><FontAwesomeIcon icon={faUser} /></span>
                                <input type="text" placeholder="Full Name" className="w-[250px] bg-transparent outline-none" />
                            </div>
                            <div className="max-w-[300px] w-full h-12 bg-gray-200 my-4 rounded-xl flex items-center">
                                <span className="w-[30px] justify-center ml-4"><FontAwesomeIcon icon={faEnvelope} /></span>
                                <input type="email" placeholder="Email ID" className="w-[250px] bg-transparent outline-none" />
                            </div>
                            <div className="max-w-[300px] w-full h-12 bg-gray-200 my-4 rounded-xl flex items-center">
                                <span className="w-[30px] justify-center ml-4"><FontAwesomeIcon icon={faLock} /></span>
                                <input type="text" placeholder="Password" className="w-[250px] bg-transparent outline-none" />
                            </div>
                            <div className="max-w-[300px] w-full h-12 bg-gray-200 my-4 rounded-xl flex items-center">
                                <span className="w-[30px] justify-center ml-4"><FontAwesomeIcon icon={faMobile} /></span>
                                <input type="number" placeholder="Mobile Number" className="w-[250px] bg-transparent outline-none" />
                            </div>
                            
                            <button type="submit" className="bg-blue-500 text-white font-semibold py-2 px-8 rounded-3xl transition-all ease-in-out duration-300 hover:ring hover:ring-blue-500 hover:bg-white hover:text-blue-500">Sign Up</button>
                            </div>
                        </form>
                    </div>
                </div>

                <div className="absolute w-full h-full top-0 left-0 flex bg-green-600">
                    <div className="flex flex-col justify-end ">
                    <div className="">
                    <h3>New here?</h3>
                    <p>Welcome to our job portal! 🌟 Whether you’re a seasoned professional or just starting your career journey, we’re here to connect you with exciting opportunities. Sign in and explore a world of possibilities!”</p>
                    <button type="submit" className="bg-blue-500 text-white font-semibold py-2 px-8 rounded-3xl transition-all ease-in-out duration-300 hover:ring hover:ring-blue-500 hover:bg-white hover:text-blue-500">Sign Up</button>
                </div>
                <img src={require('../assets/career_progres.png')} alt="" className="w-[94%]"/>
                </div>

                    <div className="flex flex-col items-end">
                    <div className="">
                    <h3>One of us?</h3>
                    <p>Welcome back! 🌟 Explore new opportunities, connect with employers, and take your career to the next level. Let’s find your dream job together!</p>
                    <button type="submit" className="bg-blue-500 text-white font-semibold py-2 px-8 rounded-3xl transition-all ease-in-out duration-300 hover:ring hover:ring-blue-500 hover:bg-white hover:text-blue-500">Sign In</button>
                </div>
                <img src={require('../assets/Job_hunt.png')} alt="" className=""/>
                </div>
                
                </div>
            </div>
        </>
    );
}

export default Register;
